{{/* Common name + labels helpers */}}

{{- define "kubeheal.name" -}}
{{- .Chart.Name -}}
{{- end -}}

{{- define "kubeheal.labels" -}}
app.kubernetes.io/name: {{ include "kubeheal.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}

{{- define "kubeheal.serviceAccountName" -}}
{{ include "kubeheal.name" . }}
{{- end -}}

{{/* The secret name to mount: an existing one if given, else our own */}}
{{- define "kubeheal.secretName" -}}
{{- if .Values.secrets.existingSecret -}}
{{ .Values.secrets.existingSecret }}
{{- else -}}
{{ include "kubeheal.name" . }}-secrets
{{- end -}}
{{- end -}}

{{/* Resolve the Redis URL: bundled service or external */}}
{{- define "kubeheal.redisUrl" -}}
{{- if .Values.redis.enabled -}}
redis://{{ include "kubeheal.name" . }}-redis:6379/0
{{- else -}}
{{ .Values.redis.externalUrl }}
{{- end -}}
{{- end -}}

{{/* Resolve the Postgres URL: bundled service or external */}}
{{- define "kubeheal.databaseUrl" -}}
{{- if .Values.postgres.enabled -}}
postgresql://{{ .Values.postgres.user }}:{{ .Values.postgres.password }}@{{ include "kubeheal.name" . }}-postgres:5432/{{ .Values.postgres.database }}
{{- else -}}
{{ .Values.postgres.externalUrl }}
{{- end -}}
{{- end -}}
