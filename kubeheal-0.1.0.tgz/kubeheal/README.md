# Deploying KubeHeal (Helm)

## 1. Build & push the image to ECR

> Build for the cluster's CPU architecture. EKS nodes are usually `amd64`; if you
> build on an Apple-silicon Mac, pass `--platform linux/amd64` or you'll get
> "exec format error" in the pod.

```bash
ACCOUNT=123456789
REGION=us-east-1
ECR=$ACCOUNT.dkr.ecr.$REGION.amazonaws.com

# once: create the repo
aws ecr create-repository --repository-name kubeheal --region $REGION

# login, build, push
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin $ECR
docker build --platform linux/amd64 -t $ECR/kubeheal:0.5.0 .
docker push $ECR/kubeheal:0.5.0
```

## 2. Create the secret (recommended over putting keys in values)

```bash
kubectl create namespace kubeheal
kubectl create secret generic kubeheal-secrets -n kubeheal \
  --from-literal=GROQ_API_KEY=gsk_... \
  --from-literal=GITHUB_TOKEN=github_pat_...
```

## 3. Install

```bash
helm install kubeheal deploy/helm/kubeheal -n kubeheal \
  --set image.repository=$ECR/kubeheal \
  --set image.tag=0.5.0 \
  --set config.githubOrg=YOUR_ORG \
  --set config.prometheusUrl=http://<your-prometheus-svc>.<ns>.svc:9090 \
  --set secrets.existingSecret=kubeheal-secrets
```

## 4. Verify

```bash
kubectl get pods -n kubeheal           # redis, watcher, worker all Running
kubectl logs -n kubeheal deploy/kubeheal-watcher   # "Watcher online..."
kubectl logs -n kubeheal deploy/kubeheal-worker    # the KUBEHEAL banner + "waiting for incidents"
```

Trigger a crash anywhere the watcher can see it and watch the worker logs produce
a full incident report.

## Notes
- **EKS + ECR (same account):** node IAM role pulls the image — no imagePullSecret needed.
- **Prometheus URL:** the default assumes the `kubeheal-prom` release in `monitoring`.
  Set `config.prometheusUrl` to your real Prometheus Service if different.
- **Scale workers:** `--set worker.replicas=3` to drain incident surges faster.
- **External Redis:** `--set redis.enabled=false --set redis.externalUrl=redis://...`
